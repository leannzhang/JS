let cn_navul = ""
let h_ul = "";
let swiper_html='';
let active_list_html='';
let active_list=[
    {imgUrl: "https://jx3.xoyo.com/uploadfile/2020/0929/20200929103456598.png", title: "预约活动开启", time: "09-29"},
    {imgUrl: "https://jx3.xoyo.com/uploadfile/2020/0929/20200929101656516.png", title: "赛季末加速", time: "09-29"},
    {imgUrl: "https://jx3.xoyo.com/uploadfile/2020/0917/20200917023604355.png", title: "中秋盛典开幕", time: "09-17"},
    {imgUrl: "https://jx3.xoyo.com/uploadfile/2020/0904/20200904011844728.png", title: "JPL职业联赛", time: "09-04"}
]
let cn_nav = [
    { title: "官网首页", ur: "#" },
    { title: "游戏特色", url: "#" },
    { title: "新闻/活动", url: "#" },
    { title: "视频/直播", url: "#" },
    { title: "同人站", url: "#" },
    { title: "下载游戏", url: "#" },
    { title: "剑网3推栏", url: "#" },
    { title: "玲珑密保锁", url: "#" },
    { title: "万宝楼", url: "#" },
    { title: "论坛", url: "#" },
    { title: "客服", url: "#" }
]
let h_nav = [
    { title: "登录", url: "login.html" },
    { title: "注册", url: "login.html" },
    { title: "充值", url: "login.html" },
    { title: "老玩家回归指南", url: "login.html" },
    { title: "客服", url: "login.html" },
    { title: "增值服务", url: "login.html" },
]
let swiper_arr=[
    {title:"校服同人征集",src:"../../Img/index/lunbo/1.jpg"},
    {title:"衍天宗门派揭秘",src:"../../Img/index/lunbo/2.jpg"},
    {title:"国庆、中秋快乐",src:"../../Img/index/lunbo/3.jpg"},
    {title:"剧情品鉴问答",src:"../../Img/index/lunbo/4.jpg"},
    {title:"全民预约",src:"../../Img/index/lunbo/5.jpg"},
]
for (let i = 0; i < h_nav.length; i++) {
    h_ul += '<li>' + '<a href=' + h_nav[i].url + '>' + h_nav[i].title + '</a>' + '</li>';
}
for (let i = 0; i < cn_nav.length; i++) {
    cn_navul += '<li>' + '<a href=' + cn_nav[i].url + '>' + cn_nav[i].title + '</a>' + '</li>';
}
for (let i = 0; i < swiper_arr.length; i++) {
    swiper_html += '<li>' + '<img src=' + swiper_arr[i].src +  '>' + '</li>';
}
for (let i = 0; i < active_list.length; i++) {
    active_list_html += '<li>' ;
    active_list_html +=  '<img src=' + active_list[i].imgUrl +  '>' ;
    active_list_html += '<h6>'+active_list[i].title+'</h6>'
    active_list_html += '<span>'+active_list[i].time+'</span>'
    active_list_html += '</li>';
}


document.getElementsByTagName("ul")[0].innerHTML = h_ul;
document.getElementsByClassName("cn_navul")[0].innerHTML = cn_navul;
document.getElementsByClassName("cn_bgabove")[0].getElementsByClassName("cn_bgleft")[0].innerHTML=swiper_html;
document.getElementsByClassName("active_list")[0].innerHTML=active_list_html;