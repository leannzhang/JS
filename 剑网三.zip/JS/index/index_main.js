
 let news_tab_bar=document.getElementsByClassName("news_tab_bar")[0].getElementsByTagName("li");
 for(let i=0;i<news_tab_bar.length;i++)
 {
     news_tab_bar[i].className="active";
 }
 let newList = {
             title: "《剑网3》新资料片预约活动开启",
             data: [
               {tip: "【新闻】", title: "《剑网3》110级校服“星演”套放送第四弹", time: "10-07"},
               {tip: "【新闻】", title: "《剑网3》110级校服“星演”套放送第三弹", time: "10-06"},
               {tip: "【新闻】", title: "《剑网3》110级校服“星演”套放送第二弹", time: "10-05"},
               {tip: "【活动】", title: "《剑网3》新资料片“奉天证道”预约活动开启", time: "09-28"},
               {tip: "【公告】", title: "10月5日1.0.0.3954版本更新内容公告", time: "10-05"}
             ]
           }
 let news_tab_info = '<h2>'+newList.title+'</h2>';
 for(let i=0;i<newList.data.length;i++)
 {
     news_tab_info+='<li>';
     news_tab_info+='<span>'+newList.data[i].tip+'</span>';
     news_tab_info+='<a href='+'#>'+newList.data[i].title+'</a>';
     news_tab_info+='<span>'+newList.data[i].time+'</span>';
     news_tab_info+='</li>';
 }
 document.getElementsByClassName("news_tab_info")[0].innerHTML=news_tab_info;
